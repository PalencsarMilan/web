import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Col, Container, Row } from 'react-bootstrap';
import '../styles/layout.css';

const Layout = () => {
    return (
        <div>
            <div>
                <Container>
                    <Row>
                        <Col className="bg-primary">1. Column</Col>
                        <Col className="bg-warning">2. Column</Col>
                        <Col className="bg-secondary">3. Column</Col>
                    </Row>
                </Container>

                <Container className="box" fluid>
                    <Row>
                        <Col>
                            <h1>Üdvözöllek!</h1>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <p>Ez egy középre igazított Bootstrap box.</p>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Button>Kattints ide</Button>
                        </Col>
                    </Row>
                </Container>

                <Container>
                    <Row>
                        <Col className="bg-danger">1. Column</Col>
                        <Col className="bg-light">2. Column</Col>
                        <Col className="bg-success">3. Column</Col>
                    </Row>
                </Container>
            </div>
        </div>
    );
};

export default Layout;
