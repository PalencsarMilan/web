import React from 'react';
import './style.css';
const Counter = () => {
    return (
        <div>
            <header>My Counter</header>
            <div id="big-container">
                <div id="felirat">
                    <p>Counter Value:</p>
                    <p id="number">100</p>
                </div>
                <br />
                <div>
                    <div>
                        <button>+</button>
                        <button>-</button>
                    </div>
                    <div>
                        <button>+</button>
                        <button>-</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Counter;
